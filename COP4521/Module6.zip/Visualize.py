"""
Name:Merrick Moncure
Date: 2/9/25
Assignmnent: Module 6: Python Dask large data set
load a large data file into a dask dataframe.
Assumptions: NA
All work below was performed by Merrick Moncure
"""
import os
# Open the image with the default viewer
os.system('xdg-open dask_dag.png')  # For Linux
# or for macOS
os.system('open dask_dag.png')
# or for Windows
os.system('start dask_dag.png')