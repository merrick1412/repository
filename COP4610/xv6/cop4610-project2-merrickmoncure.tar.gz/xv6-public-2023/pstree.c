#include "types.h"
#include "user.h"
#include "uproc.h"

#define MAXPROC 64

int getprocs(int max, struct uproc *table);

void print_tree(struct uproc *procs, int count, int parent, int level) {
    for (int i = 0; i < count; i++) {
        if (procs[i].ppid == parent) {
            for (int j = 0; j < level; j++) {
                printf(1, "   "); // Indentation
            }
            printf(1, "%s[%d]\n", procs[i].name, procs[i].pid);
            print_tree(procs, count, procs[i].pid, level + 1);
        }
    }
}

int main(void) {
    struct uproc procs[MAXPROC];
    int num = getprocs(MAXPROC, procs); // Call the syscall
    
    if (num < 0) {
        printf(1, "Error: Could not get process list.\n");
        exit();
    }

    printf(1, "Process Tree:\n");
    print_tree(procs, num, 1, 0); // Start with init process (PID 1)
    
    exit();
}

