#ifndef UPROC_H
#define UPROC_H
struct uproc {
	int pid;
	int ppid; //parent pid
	char name[16];
};
#endif // UPROC_H
