#include "types.h"
#include "stat.h"
#include "user.h"

char buf[512];

void
print(float val)
{
  //printf(1, "%f\n", val);
}

int
main(int argc, char *argv[])
{

  //if(argc != 2){
  //  exit();
  //}

  //print(1.2345);
  exit();
}
